import React from 'react';
import '../css/footer.css';

function Footer() {
    return (
        <>
            <footer>
            <h6>運営会社</h6>
        <h6>よくある質問</h6>
        <h6>お問い合わせ</h6>            </footer>
        </>
    );
}

export default Footer;